<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Результаты формы "<?php echo e($form->name); ?>"</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-bold">Результаты формы</h1>
                <p class="text-gray-600 mt-2"><?php echo e($form->name); ?></p>
            </div>
            <div class="space-x-4">
                <a href="<?php echo e(route('forms.index')); ?>" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">
                    К списку форм
                </a>
                <a href="<?php echo e(route('forms.fields.index', $form)); ?>" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                    Управление полями
                </a>
                <a href="<?php echo e(route('forms.show', $form)); ?>" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                    Заполнить форму
                </a>
                <a href="<?php echo e(route('forms.test-data', $form)); ?>" class="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700">
                    Генерация тестовых данных
                </a>
                <?php if($submissions->isNotEmpty()): ?>
                    <form action="<?php echo e(route('forms.submissions.delete', $form)); ?>" 
                          method="POST" 
                          class="inline" 
                          onsubmit="return confirm('Вы уверены, что хотите удалить все результаты?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="all" value="1">
                        <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                            Очистить все результаты
                        </button>
                    </form>
                    <button type="button" 
                            onclick="deleteSelected()" 
                            class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">
                        Удалить выбранные
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <?php if($submissions->isEmpty()): ?>
                <div class="text-center text-gray-500 py-8">
                    Пока нет отправленных форм
                </div>
            <?php else: ?>
                <div class="mb-6">
                    <form id="filterForm" action="<?php echo e(route('forms.submissions', $form)); ?>" method="GET" class="bg-white p-4 rounded-lg shadow">
                        <div id="filterContainer" class="space-y-4">
                            <?php if(request()->has('filters')): ?>
                                <?php $__currentLoopData = request('filters'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="filter-group bg-gray-50 p-4 rounded" data-group="<?php echo e($groupId); ?>">
                                        <div class="flex items-center gap-4">
                                            <?php if(!$loop->first): ?>
                                                <select name="filters[<?php echo e($groupId); ?>][logical_operator]" class="rounded-md border-gray-300">
                                                    <option value="and" <?php echo e(($filter['logical_operator'] ?? 'and') === 'and' ? 'selected' : ''); ?>>И</option>
                                                    <option value="or" <?php echo e(($filter['logical_operator'] ?? 'and') === 'or' ? 'selected' : ''); ?>>ИЛИ</option>
                                                </select>
                                            <?php endif; ?>
                                            
                                            <select name="filters[<?php echo e($groupId); ?>][field]" 
                                                    onchange="updateOperators(this)" 
                                                    class="rounded-md border-gray-300">
                                                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($field->name); ?>" 
                                                            data-type="<?php echo e($field->type); ?>"
                                                            data-options="<?php echo e(json_encode($field->options)); ?>"
                                                            <?php echo e($filter['field'] === $field->name ? 'selected' : ''); ?>>
                                                        <?php echo e($field->label); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                            <select name="filters[<?php echo e($groupId); ?>][operator]" class="rounded-md border-gray-300">
                                                <option value="=" <?php echo e(($filter['operator'] ?? '=') === '=' ? 'selected' : ''); ?>>=</option>
                                                <option value="!=" <?php echo e(($filter['operator'] ?? '=') === '!=' ? 'selected' : ''); ?>>≠</option>
                                                <option value="contains" <?php echo e(($filter['operator'] ?? '=') === 'contains' ? 'selected' : ''); ?>>Содержит</option>
                                            </select>

                                            <div class="value-container flex-grow">
                                                <?php
                                                    $field = $fields->where('name', $filter['field'])->first();
                                                ?>
                                                <?php if($field->type === 'date' || $field->type === 'time'): ?>
                                                    <div class="flex items-center gap-2">
                                                        <input type="<?php echo e($field->type); ?>" 
                                                               name="filters[<?php echo e($groupId); ?>][value][from]"
                                                               value="<?php echo e($filter['value']['from'] ?? ''); ?>"
                                                               class="rounded-md border-gray-300">
                                                        <span>до</span>
                                                        <input type="<?php echo e($field->type); ?>" 
                                                               name="filters[<?php echo e($groupId); ?>][value][to]"
                                                               value="<?php echo e($filter['value']['to'] ?? ''); ?>"
                                                               class="rounded-md border-gray-300">
                                                    </div>
                                                <?php elseif(in_array($field->type, ['select', 'radio', 'checkbox'])): ?>
                                                    <select name="filters[<?php echo e($groupId); ?>][value][]" 
                                                            multiple
                                                            class="rounded-md border-gray-300">
                                                        <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($option); ?>"
                                                                    <?php echo e(in_array($option, (array)($filter['value'] ?? [])) ? 'selected' : ''); ?>>
                                                                <?php echo e($option); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php else: ?>
                                                    <input type="text" 
                                                           name="filters[<?php echo e($groupId); ?>][value]"
                                                           value="<?php echo e($filter['value'] ?? ''); ?>"
                                                           class="rounded-md border-gray-300">
                                                <?php endif; ?>
                                            </div>

                                            <button type="button" 
                                                    onclick="removeFilterGroup(<?php echo e($groupId); ?>)" 
                                                    class="text-red-600 hover:text-red-900">
                                                Удалить
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mt-4 flex justify-between">
                            <button type="button" 
                                    onclick="addFilterGroup()" 
                                    class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                                Добавить фильтр
                            </button>
                            
                            <div class="space-x-4">
                                <a href="<?php echo e(route('forms.submissions', $form)); ?>" 
                                   class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">
                                    Сбросить
                                </a>
                                <button type="submit" 
                                        class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                                    Применить фильтры
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6 mb-4">
                    <h3 class="text-lg font-medium text-gray-700 mb-3">Экспорт результатов</h3>
                    <div class="flex items-center gap-4">
                        <div class="inline-flex rounded-md shadow-sm">
                            <form action="<?php echo e(route('forms.download.csv', $form)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <!-- Передаем текущие фильтры -->
                                <?php if(request()->has('filters')): ?>
                                    <?php $__currentLoopData = request('filters'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(is_array($value)): ?>
                                                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>][<?php echo e($k); ?>]" value="<?php echo e($v); ?>">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>]" value="<?php echo e($value); ?>">
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-l-md hover:bg-blue-700">
                                    Скачать CSV
                                </button>
                            </form>
                            <form action="<?php echo e(route('forms.download.xlsx', $form)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <!-- Передаем текущие фильтры -->
                                <?php if(request()->has('filters')): ?>
                                    <?php $__currentLoopData = request('filters'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(is_array($value)): ?>
                                                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>][<?php echo e($k); ?>]" value="<?php echo e($v); ?>">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>]" value="<?php echo e($value); ?>">
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-r-md hover:bg-green-700 border-l border-white/20">
                                    Скачать Excel
                                </button>
                            </form>
                        </div>

                        <div class="border-l pl-4 ml-4">
                            <form action="<?php echo e(route('forms.download.template', $form)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <!-- Передаем текущие фильтры -->
                                <?php if(request()->has('filters')): ?>
                                    <?php $__currentLoopData = request('filters'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(is_array($value)): ?>
                                                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>][<?php echo e($k); ?>]" value="<?php echo e($v); ?>">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>]" value="<?php echo e($value); ?>">
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <div class="flex items-center gap-4">
                                    <input type="file" 
                                           name="template" 
                                           accept=".xlsx"
                                           class="block w-full text-sm text-gray-500
                                                  file:mr-4 file:py-2 file:px-4
                                                  file:rounded-md file:border-0
                                                  file:text-sm file:font-semibold
                                                  file:bg-blue-50 file:text-blue-700
                                                  hover:file:bg-blue-100">
                                    <button type="submit" 
                                            class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                                        Заполнить шаблон
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                <th class="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Данные формы</th>
                                <th class="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Дата отправки</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        #<?php echo e($submission->id); ?>

                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="space-y-2">
                                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="text-sm">
                                                    <span class="font-medium text-gray-700">
                                                        <?php echo e($field->label); ?>:
                                                    </span>
                                                    <span class="text-gray-900">
                                                        <?php
                                                            $value = $submission->data[$field->name] ?? null;
                                                        ?>
                                                        <?php if(is_array($value)): ?>
                                                            <?php echo e(implode(', ', $value)); ?>

                                                        <?php elseif($field->type === 'date'): ?>
                                                            <?php echo e($value ? date('d.m.Y', strtotime($value)) : ''); ?>

                                                        <?php elseif($field->type === 'time'): ?>
                                                            <?php echo e($value); ?>

                                                        <?php elseif($field->dictionary_id && $value): ?>
                                                            <?php echo e($field->dictionary->items->where('value', $value)->first()?->value ?? $value); ?>

                                                        <?php else: ?>
                                                            <?php echo e($value); ?>

                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e($submission->created_at->format('d.m.Y H:i:s')); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    <?php echo e($submissions->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function toggleAll(source) {
            const checkboxes = document.getElementsByClassName('submission-checkbox');
            for (let checkbox of checkboxes) {
                checkbox.checked = source.checked;
            }
        }

        function deleteSelected() {
            const checkboxes = document.getElementsByClassName('submission-checkbox');
            const selected = Array.from(checkboxes).filter(cb => cb.checked).length;
            
            if (selected === 0) {
                alert('Выберите записи для удаления');
                return;
            }

            if (confirm(`Вы уверены, что хотите удалить ${selected} выбранных записей?`)) {
                document.getElementById('deleteForm').submit();
            }
        }

        function addFilterGroup() {
            const container = document.getElementById('filterContainer');
            const groupId = Date.now();
            
            const template = `
                <div class="filter-group bg-gray-50 p-4 rounded" data-group="${groupId}">
                    <div class="flex items-center gap-4">
                        ${container.children.length > 0 ? `
                            <select name="filters[${groupId}][logical_operator]" class="rounded-md border-gray-300">
                                <option value="and">И</option>
                                <option value="or">ИЛИ</option>
                            </select>
                        ` : ''}
                        
                        <select name="filters[${groupId}][field]" 
                                onchange="updateOperators(this)" 
                                class="rounded-md border-gray-300">
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($field->name); ?>" 
                                        data-type="<?php echo e($field->type); ?>"
                                        data-options="<?php echo e(json_encode($field->options)); ?>">
                                    <?php echo e($field->label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <select name="filters[${groupId}][operator]" class="rounded-md border-gray-300">
                            <option value="=">=</option>
                            <option value="!=">≠</option>
                            <option value="contains">Содержит</option>
                        </select>

                        <div class="value-container flex-grow">
                            <!-- Здесь будет динамически добавляться поле для значения -->
                        </div>

                        <button type="button" 
                                onclick="removeFilterGroup(${groupId})" 
                                class="text-red-600 hover:text-red-900">
                            Удалить
                        </button>
                    </div>
                </div>
            `;
            
            container.insertAdjacentHTML('beforeend', template);
            updateOperators(container.querySelector(`[data-group="${groupId}"] select[name*="[field]"]`));
        }

        function updateOperators(fieldSelect) {
            const group = fieldSelect.closest('.filter-group');
            const type = fieldSelect.selectedOptions[0].dataset.type;
            const options = JSON.parse(fieldSelect.selectedOptions[0].dataset.options || '[]');
            const valueContainer = group.querySelector('.value-container');
            
            // Очищаем контейнер значения
            valueContainer.innerHTML = '';
            
            switch (type) {
                case 'date':
                case 'time':
                    valueContainer.innerHTML = `
                        <div class="flex items-center gap-2">
                            <input type="${type}" 
                                   name="filters[${group.dataset.group}][value][from]"
                                   class="rounded-md border-gray-300">
                            <span>до</span>
                            <input type="${type}" 
                                   name="filters[${group.dataset.group}][value][to]"
                                   class="rounded-md border-gray-300">
                        </div>
                    `;
                    break;
                    
                case 'select':
                case 'radio':
                case 'checkbox':
                    valueContainer.innerHTML = `
                        <select name="filters[${group.dataset.group}][value][]" 
                                multiple
                                class="rounded-md border-gray-300">
                            ${options.map(opt => `
                                <option value="${opt}">${opt}</option>
                            `).join('')}
                        </select>
                    `;
                    break;
                    
                default:
                    valueContainer.innerHTML = `
                        <input type="text" 
                               name="filters[${group.dataset.group}][value]"
                               class="rounded-md border-gray-300">
                    `;
            }
        }

        function removeFilterGroup(groupId) {
            document.querySelector(`[data-group="${groupId}"]`).remove();
        }
    </script>
</body>
</html> <?php /**PATH D:\8fl\resources\views/form/submissions.blade.php ENDPATH**/ ?>