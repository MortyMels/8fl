<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Справочники</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold">Справочники</h1>
            <div class="space-x-4">
                <a href="<?php echo e(route('dictionaries.create')); ?>" 
                   class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Создать справочник
                </a>
                
                <!-- Форма для импорта -->
                <form action="<?php echo e(route('dictionaries.import')); ?>" 
                      method="POST" 
                      enctype="multipart/form-data" 
                      class="inline-flex items-center">
                    <?php echo csrf_field(); ?>
                    <input type="file" 
                           name="file" 
                           accept=".json"
                           required
                           class="hidden"
                           id="importFile"
                           onchange="this.form.submit()">
                    <label for="importFile" 
                           class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 cursor-pointer">
                        Импортировать справочник
                    </label>
                </form>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="bg-white rounded-lg shadow-md">
            <?php if($dictionaries->isEmpty()): ?>
                <p class="p-6 text-gray-500">Нет доступных справочников</p>
            <?php else: ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Название
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Описание
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Количество элементов
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Публичный
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Действия
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $dictionaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dictionary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e($dictionary->name); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php echo e($dictionary->description); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e($dictionary->items_count); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e($dictionary->is_public ? 'Да' : 'Нет'); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $dictionary)): ?>
                                        <a href="<?php echo e(route('dictionaries.edit', $dictionary)); ?>" 
                                           class="text-indigo-600 hover:text-indigo-900 mr-4">
                                            Редактировать
                                        </a>
                                        <a href="<?php echo e(route('dictionaries.export', $dictionary)); ?>" 
                                           class="text-blue-600 hover:text-blue-900 mr-4">
                                            Экспорт
                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $dictionary)): ?>
                                        <form action="<?php echo e(route('dictionaries.destroy', $dictionary)); ?>" 
                                              method="POST" 
                                              class="inline"
                                              onsubmit="return confirm('Вы уверены?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 hover:text-red-900">
                                                Удалить
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html> <?php /**PATH D:\8fl\resources\views/dictionaries/index.blade.php ENDPATH**/ ?>