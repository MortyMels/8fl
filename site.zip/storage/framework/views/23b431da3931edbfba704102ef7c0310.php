<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление формами</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-bold">Управление формами</h1>
                <?php if(auth()->guard()->guest()): ?>
                    <p class="text-gray-600 mt-2">
                        <a href="<?php echo e(route('login')); ?>" class="text-indigo-600 hover:text-indigo-900">Войдите</a>
                        или
                        <a href="<?php echo e(route('register')); ?>" class="text-indigo-600 hover:text-indigo-900">зарегистрируйтесь</a>
                        чтобы создавать свои формы
                    </p>
                <?php endif; ?>
            </div>
            <div class="space-x-4">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dictionaries.index')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                        Справочники
                    </a>
                    <a href="<?php echo e(route('forms.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                        Создать форму
                    </a>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">
                            Выйти
                        </button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                        Войти
                    </a>
                    <a href="<?php echo e(route('register')); ?>" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                        Регистрация
                    </a>
                <?php endif; ?>
                <form action="<?php echo e(route('forms.import')); ?>" 
                      method="POST" 
                      enctype="multipart/form-data" 
                      class="inline-flex items-center">
                    <?php echo csrf_field(); ?>
                    <input type="file" 
                           name="file" 
                           accept=".json"
                           required
                           class="hidden"
                           id="importFile"
                           onchange="this.form.submit()">
                    <label for="importFile" 
                           class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 cursor-pointer">
                        Импортировать форму
                    </label>
                </form>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="bg-white rounded-lg shadow-md p-6">
            <?php if($forms->isEmpty()): ?>
                <div class="text-center text-gray-500 py-8">
                    Нет созданных форм
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded-lg p-4">
                            <h3 class="text-xl font-semibold mb-2"><?php echo e($form->name); ?></h3>
                            <?php if($form->description): ?>
                                <p class="text-gray-600 mb-4"><?php echo e($form->description); ?></p>
                            <?php endif; ?>
                            <div class="space-y-2">
                                <a href="<?php echo e(route('forms.fields.index', $form)); ?>" 
                                   class="block text-indigo-600 hover:text-indigo-900">
                                    Управление полями
                                </a>
                                <a href="<?php echo e(route('forms.show', $form)); ?>" 
                                   class="block text-green-600 hover:text-green-900">
                                    Просмотр формы
                                </a>
                                <a href="<?php echo e(route('forms.submissions', $form)); ?>" 
                                   class="block text-blue-600 hover:text-blue-900">
                                    Результаты
                                </a>
                                <div class="flex space-x-4 mt-4">
                                    <a href="<?php echo e(route('forms.edit', $form)); ?>" 
                                       class="text-gray-600 hover:text-gray-900">
                                        Редактировать
                                    </a>
                                    <form action="<?php echo e(route('forms.destroy', $form)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900">
                                            Удалить
                                        </button>
                                    </form>
                                </div>
                                <form action="<?php echo e(route('forms.copy', $form)); ?>" 
                                      method="POST" 
                                      class="inline"
                                      onsubmit="return confirm('Вы уверены, что хотите создать копию этой формы?')">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" 
                                            class="text-blue-600 hover:text-blue-900 mr-2">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" 
                                                  stroke-linejoin="round" 
                                                  stroke-width="2" 
                                                  d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2"/>
                                        </svg>
                                    </button>
                                </form>
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e(route('forms.export', $form)); ?>" 
                                       class="text-blue-600 hover:text-blue-900"
                                       title="Экспортировать форму">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="text-sm text-gray-500 mb-2">
                                <?php if($form->user_id === auth()->id()): ?>
                                    Ваша форма
                                <?php else: ?>
                                    Владелец: <?php echo e($form->user->name); ?>

                                <?php endif; ?>
                                
                                <?php if($form->is_public): ?>
                                    <span class="ml-2 text-green-600">Публичная</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html> <?php /**PATH D:\8fl\resources\views/forms/index.blade.php ENDPATH**/ ?>