<div class="flex items-center gap-4">
    <?php if(!$isFirst): ?>
        <select name="filters[<?php echo e($groupId); ?>][logical_operator]" class="rounded-md border-gray-300">
            <option value="and" <?php echo e(($filter['logical_operator'] ?? 'and') === 'and' ? 'selected' : ''); ?>>И</option>
            <option value="or" <?php echo e(($filter['logical_operator'] ?? 'and') === 'or' ? 'selected' : ''); ?>>ИЛИ</option>
        </select>
    <?php endif; ?>
    
    <select name="filters[<?php echo e($groupId); ?>][field]" 
            onchange="updateOperators(this)" 
            class="rounded-md border-gray-300">
        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($field->name); ?>" 
                    data-type="<?php echo e($field->type); ?>"
                    data-options="<?php echo e(json_encode($field->options)); ?>"
                    <?php echo e($filter['field'] === $field->name ? 'selected' : ''); ?>>
                <?php echo e($field->label); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <select name="filters[<?php echo e($groupId); ?>][operator]" class="rounded-md border-gray-300">
        <option value="=" <?php echo e(($filter['operator'] ?? '=') === '=' ? 'selected' : ''); ?>>=</option>
        <option value="!=" <?php echo e(($filter['operator'] ?? '=') === '!=' ? 'selected' : ''); ?>>≠</option>
        <option value="contains" <?php echo e(($filter['operator'] ?? '=') === 'contains' ? 'selected' : ''); ?>>Содержит</option>
    </select>

    <div class="value-container flex-grow">
        <?php
            $field = $fields->where('name', $filter['field'])->first();
        ?>
        <?php if($field->type === 'date' || $field->type === 'time'): ?>
            <div class="flex items-center gap-2">
                <input type="<?php echo e($field->type); ?>" 
                       name="filters[<?php echo e($groupId); ?>][value][from]"
                       value="<?php echo e($filter['value']['from'] ?? ''); ?>"
                       class="rounded-md border-gray-300">
                <span>до</span>
                <input type="<?php echo e($field->type); ?>" 
                       name="filters[<?php echo e($groupId); ?>][value][to]"
                       value="<?php echo e($filter['value']['to'] ?? ''); ?>"
                       class="rounded-md border-gray-300">
            </div>
        <?php elseif(in_array($field->type, ['select', 'radio', 'checkbox'])): ?>
            <select name="filters[<?php echo e($groupId); ?>][value][]" 
                    multiple
                    class="rounded-md border-gray-300">
                <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($option); ?>"
                            <?php echo e(in_array($option, (array)($filter['value'] ?? [])) ? 'selected' : ''); ?>>
                        <?php echo e($option); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
            <input type="text" 
                   name="filters[<?php echo e($groupId); ?>][value]"
                   value="<?php echo e($filter['value'] ?? ''); ?>"
                   class="rounded-md border-gray-300">
        <?php endif; ?>
    </div>

    <button type="button" 
            onclick="removeFilterGroup(<?php echo e($groupId); ?>)" 
            class="text-red-600 hover:text-red-900">
        Удалить
    </button>
</div> <?php /**PATH D:\8fl\resources\views/form/partials/filter-group.blade.php ENDPATH**/ ?>