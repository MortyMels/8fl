<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Экспорты формы</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold">Экспорты формы "<?php echo e($form->name); ?>"</h1>
            <a href="<?php echo e(route('forms.submissions', $form)); ?>" 
               class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">
                Назад к результатам
            </a>
        </div>

        <!-- Фильтры -->
        <div class="mb-6">
            <form id="filterForm" action="<?php echo e(route('forms.exports', $form)); ?>" method="GET" class="bg-white p-4 rounded-lg shadow">
                <div id="filterContainer" class="space-y-4">
                    <?php if(request()->has('filters')): ?>
                        <?php $__currentLoopData = request('filters'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="filter-group bg-gray-50 p-4 rounded" data-group="<?php echo e($groupId); ?>">
                                <!-- Такой же код фильтров как в submissions.blade.php -->
                                <?php echo $__env->make('form.partials.filter-group', [
                                    'groupId' => $groupId,
                                    'filter' => $filter,
                                    'fields' => $fields,
                                    'isFirst' => $loop->first
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                
                <div class="mt-4 flex justify-between">
                    <button type="button" 
                            onclick="addFilterGroup()" 
                            class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                        Добавить фильтр
                    </button>
                    
                    <div class="space-x-4">
                        <a href="<?php echo e(route('forms.exports', $form)); ?>" 
                           class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">
                            Сбросить
                        </a>
                        <button type="submit" 
                                class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                            Применить фильтры
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Кнопки экспорта -->
        <div class="flex gap-4 mb-6">
            <form action="<?php echo e(route('forms.download.csv', $form)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <!-- Передаем текущие фильтры -->
                <?php if(request()->has('filters')): ?>
                    <?php $__currentLoopData = request('filters'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(is_array($value)): ?>
                                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>][<?php echo e($k); ?>]" value="<?php echo e($v); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>]" value="<?php echo e($value); ?>">
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                    Экспорт в CSV
                </button>
            </form>

            <form action="<?php echo e(route('forms.download.xlsx', $form)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <!-- Передаем текущие фильтры -->
                <?php if(request()->has('filters')): ?>
                    <?php $__currentLoopData = request('filters'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(is_array($value)): ?>
                                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>][<?php echo e($k); ?>]" value="<?php echo e($v); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <input type="hidden" name="filters[<?php echo e($groupId); ?>][<?php echo e($key); ?>]" value="<?php echo e($value); ?>">
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Экспорт в Excel
                </button>
            </form>
        </div>

        <!-- Список экспортов -->
        <div class="bg-white rounded-lg shadow-md">
            <?php if($exports->isEmpty()): ?>
                <p class="p-6 text-gray-500">Нет доступных экспортов</p>
            <?php else: ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Файл
                            </th>
                            <th class="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Формат
                            </th>
                            <th class="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Фильтры
                            </th>
                            <th class="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Дата создания
                            </th>
                            <th class="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Действия
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $exports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $export): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo e(basename($export->filename)); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php echo e(strtoupper($export->format)); ?>

                                </td>
                                <td class="px-6 py-4 text-sm text-gray-500">
                                    <?php if($export->filters): ?>
                                        <div class="space-y-1">
                                            <?php $__currentLoopData = $export->filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="text-xs">
                                                    <?php if(!$loop->first && isset($filter['logical_operator'])): ?>
                                                        <span class="font-medium"><?php echo e($filter['logical_operator'] === 'and' ? 'И' : 'ИЛИ'); ?></span>
                                                    <?php endif; ?>
                                                    <?php
                                                        $field = $fields->where('name', $filter['field'])->first();
                                                    ?>
                                                    <span class="font-medium"><?php echo e($field->label ?? $filter['field']); ?></span>
                                                    <span><?php echo e($filter['operator']); ?></span>
                                                    <?php if(is_array($filter['value'])): ?>
                                                        <?php if(isset($filter['value']['from']) && isset($filter['value']['to'])): ?>
                                                            <span>от <?php echo e($filter['value']['from']); ?> до <?php echo e($filter['value']['to']); ?></span>
                                                        <?php else: ?>
                                                            <span><?php echo e(implode(', ', $filter['value'])); ?></span>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span><?php echo e($filter['value']); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-gray-400">Без фильтров</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php echo e($export->created_at->format('d.m.Y H:i:s')); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <a href="<?php echo e(route('forms.exports.download', [$form, $export])); ?>" 
                                       class="text-indigo-600 hover:text-indigo-900">
                                        Скачать
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- Скрипты для работы с фильтрами -->
    <script>
        function addFilterGroup() {
            const container = document.getElementById('filterContainer');
            const groupId = Date.now();
            
            const template = `
                <div class="filter-group bg-gray-50 p-4 rounded" data-group="${groupId}">
                    <div class="flex items-center gap-4">
                        ${container.children.length > 0 ? `
                            <select name="filters[${groupId}][logical_operator]" class="rounded-md border-gray-300">
                                <option value="and">И</option>
                                <option value="or">ИЛИ</option>
                            </select>
                        ` : ''}
                        
                        <select name="filters[${groupId}][field]" 
                                onchange="updateOperators(this)" 
                                class="rounded-md border-gray-300">
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($field->name); ?>" 
                                        data-type="<?php echo e($field->type); ?>"
                                        data-options="<?php echo e(json_encode($field->options)); ?>">
                                    <?php echo e($field->label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <select name="filters[${groupId}][operator]" class="rounded-md border-gray-300">
                            <option value="=">=</option>
                            <option value="!=">≠</option>
                            <option value="contains">Содержит</option>
                        </select>

                        <div class="value-container flex-grow">
                            <!-- Здесь будет динамически добавляться поле для значения -->
                        </div>

                        <button type="button" 
                                onclick="removeFilterGroup(${groupId})" 
                                class="text-red-600 hover:text-red-900">
                            Удалить
                        </button>
                    </div>
                </div>
            `;
            
            container.insertAdjacentHTML('beforeend', template);
            updateOperators(container.querySelector(`[data-group="${groupId}"] select[name*="[field]"]`));
        }

        function updateOperators(fieldSelect) {
            const group = fieldSelect.closest('.filter-group');
            const type = fieldSelect.selectedOptions[0].dataset.type;
            const options = JSON.parse(fieldSelect.selectedOptions[0].dataset.options || '[]');
            const valueContainer = group.querySelector('.value-container');
            
            // Очищаем контейнер значения
            valueContainer.innerHTML = '';
            
            switch (type) {
                case 'date':
                case 'time':
                    valueContainer.innerHTML = `
                        <div class="flex items-center gap-2">
                            <input type="${type}" 
                                   name="filters[${group.dataset.group}][value][from]"
                                   class="rounded-md border-gray-300">
                            <span>до</span>
                            <input type="${type}" 
                                   name="filters[${group.dataset.group}][value][to]"
                                   class="rounded-md border-gray-300">
                        </div>
                    `;
                    break;
                    
                case 'select':
                case 'radio':
                case 'checkbox':
                    valueContainer.innerHTML = `
                        <select name="filters[${group.dataset.group}][value][]" 
                                multiple
                                class="rounded-md border-gray-300">
                            ${options.map(opt => `
                                <option value="${opt}">${opt}</option>
                            `).join('')}
                        </select>
                    `;
                    break;
                    
                default:
                    valueContainer.innerHTML = `
                        <input type="text" 
                               name="filters[${group.dataset.group}][value]"
                               class="rounded-md border-gray-300">
                    `;
            }
        }

        function removeFilterGroup(groupId) {
            document.querySelector(`[data-group="${groupId}"]`).remove();
        }
    </script>

    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
</body>
</html> <?php /**PATH D:\8fl\resources\views/form/exports.blade.php ENDPATH**/ ?>